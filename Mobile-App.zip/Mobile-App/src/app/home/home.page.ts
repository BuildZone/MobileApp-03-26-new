import { Component } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  loginUserData : any = {}

  constructor(private menu: MenuController, private _auth : AuthService, 
    private _router : Router ) {}

    


  openFirst() {
    this.menu.enable(true, 'first');
    this.menu.open('first');
  }

  openEnd() {
    this.menu.open('end');
  }

  openCustom() {
    this.menu.enable(true, 'custom');
    this.menu.open('custom');
  }

  // loginUser(){
  //   this._auth.loginUser(this.loginUserData)
  //   .subscribe(
  //     res => console.log(res),
  //     err => console.log(err)
  //   )
  // }

}
