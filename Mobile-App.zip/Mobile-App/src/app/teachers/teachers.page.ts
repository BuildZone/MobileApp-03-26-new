import { Component, OnInit } from '@angular/core';
import { TeacherService } from '../teacher.service';


@Component({
  selector: 'app-teachers',
  templateUrl: './teachers.page.html',
  styleUrls: ['./teachers.page.scss'],
})
export class TeachersPage implements OnInit {

  teachers : [];
  isShow = true;

  constructor(private _teacherService: TeacherService,) { }

  ngOnInit() {
    this._teacherService.getEvents()
    .subscribe(
      res => this.teachers=res,
      err => console.log(err)
    )
  }
  toggleDisplay(){
    this.isShow=!this.isShow;
  }

}
