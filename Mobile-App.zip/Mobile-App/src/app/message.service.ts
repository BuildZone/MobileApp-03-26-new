import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MessageService {

  private _messagesPostUrl = "http://localhost:3000/api/message";

  constructor(private http : HttpClient) { }

  postMessages(message){
    return this.http.post<any>(this._messagesPostUrl, message);
  }

}
